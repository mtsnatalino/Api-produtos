package br.edu.fatec.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import br.edu.fatec.model.Clientes;

@RestController
public class ClientesController {

	private List<Clientes> listaClientes = new ArrayList<>();
	
	@GetMapping(path = "/clientes")
	public List<Clientes> getClientes() {
		
		return this.listaClientes; 
	}
	
    @GetMapping("/clientes/cidade/{cidade}")
    public List<Clientes> getClientesByCidade(@PathVariable String cidade) {
        return listaClientes.stream()
                .filter(c -> c.getEndereco() != null && c.getEndereco().getCidade().equalsIgnoreCase(cidade))
                .collect(Collectors.toList());
    }

    @GetMapping("/clientes/instituicao/{instituicao}")
    public List<Clientes> getClientesByInstituicao(@PathVariable String instituicao) {
        return listaClientes.stream()
                .filter(c -> c.getCurso() != null && c.getCurso().getInstituicao().equalsIgnoreCase(instituicao))
                .collect(Collectors.toList());
    }

    @GetMapping("/clientes/curso/{curso}")
    public List<Clientes> getClientesByCurso(@PathVariable String curso) {
        return listaClientes.stream()
                .filter(c -> c.getCurso() != null && c.getCurso().getCurso().equalsIgnoreCase(curso))
                .collect(Collectors.toList());
    }
    
    @PostMapping("/clientes")
    public ResponseEntity<?> save(@RequestBody Clientes clientes) {
        
    	for(Clientes a : this.listaClientes) {
			
			if(a.getCpf().equals(clientes.getCpf())) {
				return ResponseEntity
						.status(HttpStatus.CONFLICT)
						.body("CPF existente");
			}
		}
		
		Integer codigo = (int) (Math.random() * 1000);
		clientes.setCodigo(codigo);
		
		this.listaClientes.add(clientes);
		return ResponseEntity
				.status(HttpStatus.CREATED)
				.body(clientes);
	}

	
	
	@DeleteMapping(path = "/clientes/{codigo}")
	public ResponseEntity<?> removerById(@PathVariable(name = "codigo") Integer codigo) {
		
		Clientes clientesRemocao = null;
		
		for(Clientes c : this.listaClientes) {
			
			if(codigo.equals(c.getCodigo())) {
				clientesRemocao = c;
			}
		}
		
		this.listaClientes.remove(clientesRemocao);
		
		return ResponseEntity.status(HttpStatus.NO_CONTENT).body(null);
	}
	
}
	