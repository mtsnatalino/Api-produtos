package br.edu.fatec;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FatecApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(FatecApiApplication.class, args);
	}

}
