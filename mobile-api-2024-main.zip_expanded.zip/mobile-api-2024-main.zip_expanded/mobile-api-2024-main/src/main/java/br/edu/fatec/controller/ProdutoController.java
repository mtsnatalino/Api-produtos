package br.edu.fatec.controller;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import br.edu.fatec.model.Produto;
import br.edu.fatec.repository.ProdutoRepository;

@RestController
public class ProdutoController {

	private List<Produto> listaProdutos = new ArrayList<>();
	
	@Autowired
	private ProdutoRepository produtoRepository;
	
	@GetMapping(path = "/produtos")
	public List<Produto> getProduto(@RequestParam(name = "descricao", required = false) String descricao) {
		
		List<Produto> lista = this.produtoRepository.findAll();
		
		return lista;
	}
	
	@GetMapping("/produtos/id/{id}")
	public ResponseEntity<?> getProdutoById(@PathVariable(name = "id") Integer id) {
		
		Produto produtoProcurado = this.produtoRepository.findById(id).orElse(null);
		
		if(produtoProcurado != null) {
			return ResponseEntity.status(HttpStatus.OK).body(produtoProcurado);
		}
		
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
	}
	
	@GetMapping("/produtos/descricao/{descricao}")
	public ResponseEntity<?> getProdutoByDescricao(@PathVariable(name = "descricao") String descricao) {
		
		Produto produtoProcurado = this.produtoRepository.findByDescricao(descricao).orElse(null);
		
		if(produtoProcurado != null) {
			return ResponseEntity.status(HttpStatus.OK).body(produtoProcurado);
		}
		
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
	}
	
	@GetMapping("/produtos/marca/{marca}")
	public ResponseEntity<?> getProdutoByMarca(@PathVariable(name = "marca") String marca) {
		
		Produto produtoProcurado = this.produtoRepository.findByMarca(marca).orElse(null);
		
		if(produtoProcurado != null) {
			return ResponseEntity.status(HttpStatus.OK).body(produtoProcurado);
		}
		
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
	}
	
	@GetMapping("/produtos/estoque/{estoque}")
	public ResponseEntity<?> getProdutoByEstoque(@PathVariable(name = "estoque") Integer estoque) {
		
		Produto produtoProcurado = this.produtoRepository.findByEstoque(estoque).orElse(null);
		
		if(produtoProcurado != null) {
			return ResponseEntity.status(HttpStatus.OK).body(produtoProcurado);
		}
		
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
	}
	
	@PostMapping("/produtos")
	public ResponseEntity<?> save(@RequestBody Produto produto) {
		
		Produto produtoSalvado = this.produtoRepository.save(produto);
		return ResponseEntity.status(HttpStatus.CREATED).body(produtoSalvado);
	}
	
	@PutMapping("/produtos/{id}")
	public ResponseEntity<?> updateProduto(@PathVariable(name = "id") Integer id, @RequestBody Produto produtoAtualizado) {
	    Produto produtoExistente = this.produtoRepository.findById(id).orElse(null);
	    
	    if (produtoExistente != null) {
	 
	        produtoExistente.setDescricao(produtoAtualizado.getDescricao());
	        produtoExistente.setMarca(produtoAtualizado.getMarca());
	        produtoExistente.setValor(produtoAtualizado.getValor());
	        produtoExistente.setEstoque(produtoAtualizado.getEstoque());
	        
	        
	        Produto produtoSalvo = this.produtoRepository.save(produtoExistente);
	        return ResponseEntity.status(HttpStatus.OK).body(produtoSalvo);
	    }
	    
	    return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Produto não encontrado");
	}
	
	@DeleteMapping(path = "/produtos/id/{id}")
	public ResponseEntity<?> removerById(@PathVariable(name = "id") Integer id) {
		
		 if (produtoRepository.existsById(id)) {
	            produtoRepository.deleteById(id);
	            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(null);
	        }
	        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Produto não encontrado");
	    }
}
